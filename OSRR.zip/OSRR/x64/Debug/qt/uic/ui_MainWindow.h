/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *mainLayout;
    QHBoxLayout *topControls;
    QPushButton *loadButton;
    QPushButton *startButton;
    QLabel *label;
    QSpinBox *intervalSpinBox;
    QLabel *label_2;
    QSpinBox *timeSliceSpinBox;
    QHBoxLayout *queueLayout;
    QGroupBox *groupReady;
    QVBoxLayout *vboxLayout;
    QListWidget *readyList;
    QGroupBox *groupInput;
    QVBoxLayout *vboxLayout1;
    QListWidget *inputList;
    QGroupBox *groupOutput;
    QVBoxLayout *vboxLayout2;
    QListWidget *outputList;
    QGroupBox *groupWait;
    QVBoxLayout *vboxLayout3;
    QListWidget *waitList;
    QHBoxLayout *hboxLayout;
    QGroupBox *groupRunning;
    QVBoxLayout *vboxLayout4;
    QLabel *runningLabel;
    QGroupBox *groupLog;
    QVBoxLayout *vboxLayout5;
    QTextEdit *logTextEdit;
    QHBoxLayout *logButtons;
    QSpacerItem *spacer;
    QPushButton *clearLogButton;
    QPushButton *saveLogButton;
    QPushButton *openLogButton;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1011, 652);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        mainLayout = new QVBoxLayout(centralwidget);
        mainLayout->setObjectName(QString::fromUtf8("mainLayout"));
        topControls = new QHBoxLayout();
        topControls->setObjectName(QString::fromUtf8("topControls"));
        loadButton = new QPushButton(centralwidget);
        loadButton->setObjectName(QString::fromUtf8("loadButton"));

        topControls->addWidget(loadButton);

        startButton = new QPushButton(centralwidget);
        startButton->setObjectName(QString::fromUtf8("startButton"));

        topControls->addWidget(startButton);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        topControls->addWidget(label);

        intervalSpinBox = new QSpinBox(centralwidget);
        intervalSpinBox->setObjectName(QString::fromUtf8("intervalSpinBox"));
        intervalSpinBox->setMinimum(100);
        intervalSpinBox->setMaximum(5000);
        intervalSpinBox->setSingleStep(100);
        intervalSpinBox->setValue(100);

        topControls->addWidget(intervalSpinBox);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        topControls->addWidget(label_2);

        timeSliceSpinBox = new QSpinBox(centralwidget);
        timeSliceSpinBox->setObjectName(QString::fromUtf8("timeSliceSpinBox"));
        timeSliceSpinBox->setMinimum(1);
        timeSliceSpinBox->setMaximum(100);
        timeSliceSpinBox->setValue(5);

        topControls->addWidget(timeSliceSpinBox);


        mainLayout->addLayout(topControls);

        queueLayout = new QHBoxLayout();
        queueLayout->setObjectName(QString::fromUtf8("queueLayout"));
        groupReady = new QGroupBox(centralwidget);
        groupReady->setObjectName(QString::fromUtf8("groupReady"));
        vboxLayout = new QVBoxLayout(groupReady);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        readyList = new QListWidget(groupReady);
        readyList->setObjectName(QString::fromUtf8("readyList"));

        vboxLayout->addWidget(readyList);


        queueLayout->addWidget(groupReady);

        groupInput = new QGroupBox(centralwidget);
        groupInput->setObjectName(QString::fromUtf8("groupInput"));
        vboxLayout1 = new QVBoxLayout(groupInput);
        vboxLayout1->setObjectName(QString::fromUtf8("vboxLayout1"));
        inputList = new QListWidget(groupInput);
        inputList->setObjectName(QString::fromUtf8("inputList"));

        vboxLayout1->addWidget(inputList);


        queueLayout->addWidget(groupInput);

        groupOutput = new QGroupBox(centralwidget);
        groupOutput->setObjectName(QString::fromUtf8("groupOutput"));
        vboxLayout2 = new QVBoxLayout(groupOutput);
        vboxLayout2->setObjectName(QString::fromUtf8("vboxLayout2"));
        outputList = new QListWidget(groupOutput);
        outputList->setObjectName(QString::fromUtf8("outputList"));

        vboxLayout2->addWidget(outputList);


        queueLayout->addWidget(groupOutput);

        groupWait = new QGroupBox(centralwidget);
        groupWait->setObjectName(QString::fromUtf8("groupWait"));
        vboxLayout3 = new QVBoxLayout(groupWait);
        vboxLayout3->setObjectName(QString::fromUtf8("vboxLayout3"));
        waitList = new QListWidget(groupWait);
        waitList->setObjectName(QString::fromUtf8("waitList"));

        vboxLayout3->addWidget(waitList);


        queueLayout->addWidget(groupWait);


        mainLayout->addLayout(queueLayout);

        hboxLayout = new QHBoxLayout();
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        groupRunning = new QGroupBox(centralwidget);
        groupRunning->setObjectName(QString::fromUtf8("groupRunning"));
        vboxLayout4 = new QVBoxLayout(groupRunning);
        vboxLayout4->setObjectName(QString::fromUtf8("vboxLayout4"));
        runningLabel = new QLabel(groupRunning);
        runningLabel->setObjectName(QString::fromUtf8("runningLabel"));

        vboxLayout4->addWidget(runningLabel);


        hboxLayout->addWidget(groupRunning);

        groupLog = new QGroupBox(centralwidget);
        groupLog->setObjectName(QString::fromUtf8("groupLog"));
        vboxLayout5 = new QVBoxLayout(groupLog);
        vboxLayout5->setObjectName(QString::fromUtf8("vboxLayout5"));
        logTextEdit = new QTextEdit(groupLog);
        logTextEdit->setObjectName(QString::fromUtf8("logTextEdit"));
        logTextEdit->setReadOnly(true);

        vboxLayout5->addWidget(logTextEdit);

        logButtons = new QHBoxLayout();
        logButtons->setObjectName(QString::fromUtf8("logButtons"));
        spacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        logButtons->addItem(spacer);

        clearLogButton = new QPushButton(groupLog);
        clearLogButton->setObjectName(QString::fromUtf8("clearLogButton"));

        logButtons->addWidget(clearLogButton);

        saveLogButton = new QPushButton(groupLog);
        saveLogButton->setObjectName(QString::fromUtf8("saveLogButton"));

        logButtons->addWidget(saveLogButton);

        openLogButton = new QPushButton(groupLog);
        openLogButton->setObjectName(QString::fromUtf8("openLogButton"));

        logButtons->addWidget(openLogButton);


        vboxLayout5->addLayout(logButtons);


        hboxLayout->addWidget(groupLog);

        hboxLayout->setStretch(0, 3);
        hboxLayout->setStretch(1, 7);

        mainLayout->addLayout(hboxLayout);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "\346\227\266\351\227\264\347\211\207\350\275\256\350\275\254\350\260\203\345\272\246\346\250\241\346\213\237\347\263\273\347\273\237", nullptr));
        loadButton->setText(QApplication::translate("MainWindow", "\345\212\240\350\275\275\346\226\207\344\273\266", nullptr));
        startButton->setText(QApplication::translate("MainWindow", "\345\274\200\345\247\213\350\260\203\345\272\246", nullptr));
        label->setText(QApplication::translate("MainWindow", "                     \346\257\217\347\211\207(ms):", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "          \346\227\266\351\227\264\347\211\207\346\225\260:", nullptr));
        groupReady->setTitle(QApplication::translate("MainWindow", "\345\260\261\347\273\252\351\230\237\345\210\227", nullptr));
        groupInput->setTitle(QApplication::translate("MainWindow", "\350\276\223\345\205\245\347\255\211\345\276\205", nullptr));
        groupOutput->setTitle(QApplication::translate("MainWindow", "\350\276\223\345\207\272\347\255\211\345\276\205", nullptr));
        groupWait->setTitle(QApplication::translate("MainWindow", "\345\205\266\344\273\226\347\255\211\345\276\205", nullptr));
        groupRunning->setTitle(QApplication::translate("MainWindow", "\345\275\223\345\211\215\350\277\220\350\241\214\350\277\233\347\250\213", nullptr));
        runningLabel->setText(QApplication::translate("MainWindow", "               \346\227\240", nullptr));
        groupLog->setTitle(QApplication::translate("MainWindow", "\350\260\203\345\272\246\346\227\245\345\277\227", nullptr));
        clearLogButton->setText(QApplication::translate("MainWindow", "\346\270\205\347\251\272\346\227\245\345\277\227", nullptr));
        saveLogButton->setText(QApplication::translate("MainWindow", "\344\277\235\345\255\230\346\227\245\345\277\227", nullptr));
        openLogButton->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200\346\227\245\345\277\227", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
